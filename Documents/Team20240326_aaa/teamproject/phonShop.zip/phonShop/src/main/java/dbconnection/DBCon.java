package dbconnection;

public abstract class DBCon {
	public final static String URL="jdbc:mysql://localhost:3306/phonshopdb?serverTimezone=UTC";
	public final static String USER="root" ;
	public final static String PASSWORD= "my1234";
}
