package com.choong.biz.order;

public class OrderDTO {

}
