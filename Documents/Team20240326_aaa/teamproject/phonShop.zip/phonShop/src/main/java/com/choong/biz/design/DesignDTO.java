package com.choong.biz.design;

public class DesignDTO {

}
