package com.choong.biz.product;

public class ProductDTO {

}
