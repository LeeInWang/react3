package com.choong.biz.category;

public class CategoryDAO {

}
