package com.choong.biz.statistics;

public class StatisticsDAO {

}
