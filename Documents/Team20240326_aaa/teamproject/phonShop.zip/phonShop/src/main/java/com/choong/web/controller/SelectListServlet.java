package com.choong.web.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.choong.biz.board.BoardDAO;
import com.choong.biz.board.BoardDTO;
import com.choong.biz.user.UserDAO;
import com.choong.biz.user.UserDTO;


@WebServlet("*.do3")
public class SelectListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//먼저 한글 필터 처리 부터 하기   

    public SelectListServlet() {
        super();
      
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//#1. 사용자 요청이 들어오면 요청 경로(path)를 추출
		final String URI = request.getRequestURI();
		final String PATH =	URI.substring(URI.lastIndexOf("/"));
		
		//요청에 따라 처리하기
		 if(PATH.equals("/getUserGrade.do3")) {
				System.out.println("글 상세 조회 처리");
				//타이틀 누르면 상세 조회되게
				
				//사용자 입력 정보
				String userId = request.getParameter("userId");
				
				UserDTO dto = new UserDTO();
				dto.setUserId(userId);
			
				
				
				UserDAO dao = new UserDAO();
				UserDTO userList = dao.getUser(dto.getUserId());
				
				request.setAttribute("userList", userList);
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("/phone/user/userManagementUpdate.jsp");
				dispatcher.forward(request, response);	
				
				
			}
		
	}

}
