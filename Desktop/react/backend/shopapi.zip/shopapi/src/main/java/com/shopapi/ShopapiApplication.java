package com.shopapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopapiApplication.class, args);
	}

}
